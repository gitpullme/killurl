// KillURL MAIN World Injector
// This script runs in the page's MAIN JS world (not isolated extension world)
// 
// STRATEGY:
// 1. On KNOWN shortener domains → auto-activate at document_start (hooks timers before page JS runs)
// 2. On UNKNOWN domains → stay dormant, activate only on user's "Skip" click
// 3. After DOM loads → check for Cloudflare/captcha → if found, DEACTIVATE and restore original timers
// 4. On force-skip → activate + clear all timers + zero countdown variables
// 5. On STREAMING domains → hook EME/DRM APIs IMMEDIATELY for screen share bypass

(function () {
    'use strict';

    // Prevent double initialization if injected via manifest and script tag
    if (window.__killurl_injector_loaded) return;
    window.__killurl_injector_loaded = true;

    const TIMER_THRESHOLD = 2000;
    const FAST_FORWARD_DELAY = 10;
    const DEBUG = false;

    function log(...args) {
        if (DEBUG) console.log('[KillURL:MAIN]', ...args);
    }

    // ===== STATE =====
    let activated = false;
    let deactivated = false; // Set true if security page detected AFTER activation
    let varKillInterval = null;
    let aggressiveMode = false; // Set via event from content script
    let reactivationWatcher = null;
    let trackedIntervals = new Map(); // Track interval callbacks for force-skip

    // ===== DRM BYPASS STATE =====
    let drmBypassEnabled = false;
    let drmBypassActivated = false;
    let pendingEMECalls = []; // Queue EME calls until settings are confirmed
    let settingsReceived = false; // Whether content.js has sent settings

    // ===== STREAMING PLATFORM DOMAINS (for DRM bypass) =====
    const STREAMING_DOMAINS = [
        'netflix.com', 'disneyplus.com', 'hotstar.com',
        'hulu.com', 'hbomax.com', 'max.com',
        'primevideo.com', 'amazon.com',
        'peacocktv.com', 'paramountplus.com',
        'crunchyroll.com', 'funimation.com',
        'tv.apple.com', 'youtube.com', 'music.youtube.com',
        'spotify.com', 'twitch.tv',
        'jiocinema.com', 'sonyliv.com', 'zee5.com',
        'voot.com', 'mxplayer.in',
    ];

    function isStreamingDomain() {
        const hostname = window.location.hostname.replace(/^www\./, '').toLowerCase();
        return STREAMING_DOMAINS.some(d => hostname === d || hostname.endsWith('.' + d));
    }

    // Save originals IMMEDIATELY
    const _origSetTimeout = window.setTimeout.bind(window);
    const _origSetInterval = window.setInterval.bind(window);
    const _origClearTimeout = window.clearTimeout.bind(window);
    const _origClearInterval = window.clearInterval.bind(window);

    // ===== KNOWN SHORTENER DOMAINS (for auto-activation) =====
    // This list enables timer hooking at document_start on known sites
    const KNOWN_DOMAINS = [
        'adf.ly', 'adfoc.us', 'bc.vc', 'j.gs', 'q.gs',
        'shorte.st', 'sh.st', 'ouo.io', 'ouo.press',
        'za.gl', 'za.mn', 'adfly.com',
        'linkvertise.com', 'linkvertise.net', 'link-to.net',
        'direct-link.net', 'linkvertise.download',
        'shrinkme.io', 'shrink.pe',
        'exe.io', 'exey.io', 'exe.app',
        'gplinks.co', 'gplinks.in',
        'droplinks.co', 'droplink.co',
        'mdiskshortner.link', 'mdisk.me',
        'adrinolinks.in', 'adrinolinks.com',
        'earnl.xyz', 'earnlink.xyz',
        'link1s.com', 'link1s.net',
        'cuty.io', 'cutt.ly', 'cutt.us',
        'shrtfly.com', 'shrtfly.net',
        'za.uy', 'shorturl.at',
        'tei.ai', 'tii.ai',
        'linkpays.in',
        'try2link.com', 'try2links.com',
        'ez4short.com', 'ez4links.com',
        'rslinks.net', 'technorozen.com',
        'tnlink.in', 'tnshort.net',
        'atglinks.com', 'indianshortner.com',
        'dulink.in', 'xpshort.com',
        'iir.ai', 'reqlinks.net',
        'krfrn.xyz', 'kfrn.xyz',
        'modishortner.com',
        'clicksfly.com', 'fc-lc.com', 'fc.lc',
        'earnhub.net', 'mboost.me',
        // Indian shorteners / redirectors with countdowns
        'just2earn.com', 'earnbox.in',
        'whatsagrouplink.online',
        'usalinkz.com', 'techymozo.com',
        'teraboxlink.com', 'earnkaro.com',
        'shortnerfly.com', 'earn.wiki',
        'upshrink.com', 'moneycase.net',
        'gyanilinks.com', 'shareus.io', 'shareus.site',
        'link-target.net', 'links4earn.com',
        'linksfree.net', 'earnl.net',
        'shortzon.com', 'link-hub.net',
        'hindilinks4u.to', 'insurancegold.in',
        'grantph.one', 'financerites.com',
        'bindaaslinks.com',
        'go.bloggingaro.com', 'go.linkbnao.com',
        'go.crazyblog.in', 'go.techoreels.com',
        'go.flashlink.in', 'go.earnforinfo.com',
        'short2url.in', 'grfrn.xyz',
        'urlshortx.com', 'linkbn.com',
    ];

    // ===== DRM/EME BYPASS (for screen sharing) =====
    // This MUST be hooked synchronously at document_start on streaming domains
    // because streaming players call requestMediaKeySystemAccess during initialization

    const _origRequestMKSA = navigator.requestMediaKeySystemAccess
        ? navigator.requestMediaKeySystemAccess.bind(navigator)
        : null;

    function activateDRMBypass() {
        if (drmBypassActivated) return;
        if (!_origRequestMKSA) return;
        drmBypassActivated = true;

        console.log('[KillURL] 🖥️ DRM Screen Share bypass ACTIVATED on', window.location.hostname);

        // Override requestMediaKeySystemAccess
        navigator.requestMediaKeySystemAccess = function (keySystem, supportedConfigurations) {
            console.log('[KillURL] 🔑 Intercepted EME request:', keySystem);

            // If DRM bypass is confirmed disabled, pass through
            if (settingsReceived && !drmBypassEnabled) {
                console.log('[KillURL] DRM bypass disabled by settings, passing through');
                return _origRequestMKSA(keySystem, supportedConfigurations);
            }

            // Log original robustness levels
            supportedConfigurations.forEach((config, i) => {
                if (config.videoCapabilities) {
                    config.videoCapabilities.forEach(cap => {
                        console.log(`[KillURL] Original video robustness: "${cap.robustness}" → forcing "" (software/L3)`);
                    });
                }
            });

            // Modify configurations to force software-based decryption
            const modifiedConfigs = supportedConfigurations.map(config => {
                const newConfig = { ...config };

                // Force software secure decode for video
                if (newConfig.videoCapabilities) {
                    newConfig.videoCapabilities = newConfig.videoCapabilities.map(cap => ({
                        ...cap,
                        robustness: '' // Empty = software decode (Widevine L3)
                    }));
                }

                // Force software secure decode for audio
                if (newConfig.audioCapabilities) {
                    newConfig.audioCapabilities = newConfig.audioCapabilities.map(cap => ({
                        ...cap,
                        robustness: '' // Empty = software decode (Widevine L3)
                    }));
                }

                // Remove persistentState requirement which can force hardware
                if (newConfig.persistentState === 'required') {
                    newConfig.persistentState = 'optional';
                }

                // Remove distinctiveIdentifier which can force hardware
                if (newConfig.distinctiveIdentifier === 'required') {
                    newConfig.distinctiveIdentifier = 'optional';
                }

                return newConfig;
            });

            console.log('[KillURL] ✅ EME configs modified → forced software decode (Widevine L3)');

            // Try modified configs first, fall back to original if they fail
            return _origRequestMKSA(keySystem, modifiedConfigs).catch(err => {
                console.log('[KillURL] ⚠️ Modified configs rejected, falling back to original:', err.message);
                return _origRequestMKSA(keySystem, supportedConfigurations);
            });
        };

        // Also override MediaKeySystemAccess.createMediaKeys if available
        // to ensure software-only processing
        try {
            const origCreateMediaKeys = MediaKeySystemAccess.prototype.createMediaKeys;
            MediaKeySystemAccess.prototype.createMediaKeys = function () {
                log('Intercepted createMediaKeys');
                return origCreateMediaKeys.call(this);
            };
        } catch (e) { /* ignore */ }

        // Process video elements for software compositing
        function processVideoElements() {
            const videos = document.querySelectorAll('video');
            videos.forEach(video => {
                if (video.__killurl_drm_processed) return;
                video.__killurl_drm_processed = true;

                // Force software compositing layer
                video.style.setProperty('transform', 'translateZ(0)', 'important');
                video.style.setProperty('-webkit-transform', 'translateZ(0)', 'important');
                video.style.setProperty('backface-visibility', 'hidden', 'important');
                video.style.setProperty('-webkit-backface-visibility', 'hidden', 'important');
                video.style.setProperty('will-change', 'auto', 'important');
                video.style.setProperty('image-rendering', 'auto', 'important');

                log('Processed video element for screen share');
            });
        }

        // Watch for dynamically added video elements
        const videoObserver = new MutationObserver(() => {
            processVideoElements();
        });

        // Start observing when DOM is available
        if (document.documentElement) {
            videoObserver.observe(document.documentElement, {
                childList: true,
                subtree: true
            });
        } else {
            // Wait for documentElement to be available
            const waitForDoc = _origSetInterval(() => {
                if (document.documentElement) {
                    _origClearInterval(waitForDoc);
                    videoObserver.observe(document.documentElement, {
                        childList: true,
                        subtree: true
                    });
                    processVideoElements();
                }
            }, 10);
        }

        // Also process when DOM is ready
        window.addEventListener('DOMContentLoaded', processVideoElements);
        window.addEventListener('load', processVideoElements);

        // Dispatch event to notify content script
        try {
            window.dispatchEvent(new CustomEvent('killurl-drm-bypass-active'));
        } catch (e) { /* ignore */ }
    }

    // Listen for DRM bypass enable/disable from content script
    window.addEventListener('killurl-enable-drm-bypass', (e) => {
        const shouldEnable = !!e.detail?.enabled;
        settingsReceived = true;
        drmBypassEnabled = shouldEnable;
        log('DRM bypass setting received:', shouldEnable);

        if (shouldEnable && !drmBypassActivated) {
            activateDRMBypass();
        }
    });

    // Listen for on-demand DRM bypass activation (from popup button)
    window.addEventListener('killurl-force-drm-bypass', () => {
        log('Force DRM bypass triggered');
        drmBypassEnabled = true;
        if (!drmBypassActivated) {
            activateDRMBypass();
        }
    });

    // ===== URL-BASED SECURITY PAGE DETECTION (synchronous, at document_start) =====

    function isSecurityURL() {
        const url = window.location.href.toLowerCase();
        const hostname = window.location.hostname.toLowerCase();
        if (url.includes('/cdn-cgi/') && url.includes('challenge')) return true;
        if (hostname.includes('challenges.cloudflare.com')) return true;
        if (url.includes('/turnstile/')) return true;
        if (hostname.includes('recaptcha.net')) return true;
        if (hostname.includes('hcaptcha.com')) return true;
        return false;
    }

    // ===== DOM-BASED SECURITY DETECTION (after DOM loads) =====

    function hasSecurityMarkers() {
        try {
            const html = document.documentElement?.innerHTML || '';

            // Cloudflare challenge HTML markers
            if (html.includes('id="cf-challenge-running"') ||
                html.includes('id="challenge-running"') ||
                html.includes('cf-turnstile-wrapper') ||
                html.includes('id="challenge-form"') ||
                html.includes('id="challenge-stage"') ||
                html.includes('cf-chl-widget')) {
                return true;
            }

            // Cloudflare JS challenge scripts
            if (html.includes('/cdn-cgi/challenge-platform/') ||
                html.includes('cpo.src') ||
                html.includes('cNonce')) {
                return true;
            }

            const bodyText = document.body?.textContent || '';

            // Cloudflare "checking" page text (very specific to avoid false positives)
            if (bodyText.includes('Performing security verification') &&
                bodyText.includes('security service')) {
                return true;
            }
            if (bodyText.includes('Checking if the site connection is secure') &&
                html.includes('cf-')) {
                return true;
            }
            if (bodyText.includes('DDoS protection by') && bodyText.includes('Cloudflare')) {
                return true;
            }
            if (bodyText.includes('Just a moment...') && html.includes('cf-challenge')) {
                return true;
            }

        } catch (e) { /* ignore */ }
        return false;
    }

    // ===== COUNTDOWN VARIABLE NAMES =====

    const COUNTDOWN_VAR_NAMES = [
        'counter', 'countdown', 'timer', 'count', 'seconds',
        'timeLeft', 'time_left', 'remaining', 'wait', 'Wait',
        'sec', 'second', 'delay', 'currentTime', 'current_time',
        'wpsafe_timer', 'wpsafelink_timer', 'wpsafe_count',
        'ctt', 'cnt', 'secs', 'timerCount', 'timerVal',
        'countdownTimer', 'countDown', 'countValue', 'counterValue',
        'secondsLeft', 'seconds_left', 'time_remaining',
        'waitTime', 'wait_time', 'waitSeconds', 'wait_seconds',
        'redirectTime', 'redirect_time', 'redirectTimer',
        'downloadTimer', 'download_timer', 'dlTimer',
        'linkTimer', 'link_timer', 'shortTimer', 'short_timer',
        'countdownSeconds', 'countdown_seconds',
        'timeCounter', 'time_counter', 'secondCounter',
        'scrollTimer', 'scroll_timer', 'scrollCount', 'scroll_count',
        // earnbox.in specific variables
        'earnboxTimer', 'earnbox_timer', 'earnboxCount', 'earnbox_count',
        'timeRemaining', 'secondsRemaining',
    ];

    // ===== CHECK IF CURRENT DOMAIN IS A KNOWN SHORTENER =====

    function isKnownDomain() {
        const hostname = window.location.hostname.replace(/^www\./, '').toLowerCase();
        return KNOWN_DOMAINS.some(d => hostname === d || hostname.endsWith('.' + d));
    }

    // ===== TIMER HOOKS =====

    function activateTimerHooks() {
        if (activated) return;
        activated = true;

        window.setTimeout = function (callback, delay, ...args) {
            if (deactivated) return _origSetTimeout(callback, delay, ...args);

            if (typeof delay === 'number' && delay > TIMER_THRESHOLD) {
                log(`Intercepted setTimeout: ${delay}ms → ${FAST_FORWARD_DELAY}ms`);

                const id = _origSetTimeout(callback, FAST_FORWARD_DELAY, ...args);

                try {
                    window.dispatchEvent(new CustomEvent('killurl-timer-intercepted', {
                        detail: { type: 'timeout', originalDelay: delay, newDelay: FAST_FORWARD_DELAY }
                    }));
                } catch (e) { /* ignore */ }

                return id;
            }
            return _origSetTimeout(callback, delay, ...args);
        };

        window.setInterval = function (callback, delay, ...args) {
            if (deactivated) return _origSetInterval(callback, delay, ...args);

            if (typeof delay === 'number' && delay > TIMER_THRESHOLD) {
                log(`Intercepted setInterval: ${delay}ms → ${FAST_FORWARD_DELAY}ms`);

                // Fire callback immediately to advance countdown
                try { callback.call(window, ...args); } catch (e) { /* ignore */ }

                const id = _origSetInterval(callback, FAST_FORWARD_DELAY, ...args);

                // Track so force-skip can fire it one last time before clearing
                trackedIntervals.set(id, { callback, args });

                try {
                    window.dispatchEvent(new CustomEvent('killurl-timer-intercepted', {
                        detail: { type: 'interval', originalDelay: delay, newDelay: FAST_FORWARD_DELAY }
                    }));
                } catch (e) { /* ignore */ }

                return id;
            }

            // Also track non-intercepted intervals (countdown intervals with short delays)
            const id = _origSetInterval(callback, delay, ...args);
            if (typeof delay === 'number' && delay >= 500 && delay <= 2000) {
                trackedIntervals.set(id, { callback, args });
            }
            return id;
        };

        log('Timer hooks activated');
    }

    function deactivateTimerHooks() {
        deactivated = true;
        // Restore original functions
        window.setTimeout = _origSetTimeout;
        window.setInterval = _origSetInterval;

        // Stop var killing
        if (varKillInterval) {
            _origClearInterval(varKillInterval);
            varKillInterval = null;
        }

        log('Timer hooks DEACTIVATED (security page)');

        // If aggressive mode is on, start watching for CF challenge completion
        if (aggressiveMode && !isActualChallengeFrame()) {
            startReactivationWatcher();
        }
    }

    // ===== AGGRESSIVE MODE: RE-ACTIVATION AFTER CF COMPLETES =====

    function isActualChallengeFrame() {
        // Never re-activate on actual Cloudflare challenge iframe/page
        const hostname = window.location.hostname.toLowerCase();
        return hostname.includes('challenges.cloudflare.com') ||
            hostname.includes('recaptcha.net') ||
            hostname.includes('hcaptcha.com');
    }

    function startReactivationWatcher() {
        if (reactivationWatcher) return;
        log('Aggressive mode: watching for CF challenge completion...');

        let checkCount = 0;
        const MAX_CHECKS = 30; // 30 checks × 2s = 60s max

        // Method 1: MutationObserver for CF element removal
        const observer = new MutationObserver(() => {
            if (!hasSecurityMarkers()) {
                log('Aggressive mode: CF markers gone (mutation) — re-activating!');
                cleanupWatcher(observer);
                reactivate();
            }
        });

        try {
            observer.observe(document.documentElement, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ['style', 'class', 'id']
            });
        } catch (e) { /* ignore */ }

        // Method 2: Periodic polling as backup
        reactivationWatcher = _origSetInterval(() => {
            checkCount++;
            if (checkCount > MAX_CHECKS) {
                log('Aggressive mode: timed out waiting for CF completion');
                cleanupWatcher(observer);
                return;
            }
            if (!hasSecurityMarkers()) {
                log('Aggressive mode: CF markers gone (poll) — re-activating!');
                cleanupWatcher(observer);
                reactivate();
            }
        }, 2000);

        function cleanupWatcher(obs) {
            try { obs.disconnect(); } catch (e) { /* */ }
            if (reactivationWatcher) {
                _origClearInterval(reactivationWatcher);
                reactivationWatcher = null;
            }
        }
    }

    function reactivate() {
        if (!aggressiveMode) return;
        log('Re-activating timer hooks after CF challenge completion');
        deactivated = false;
        activated = false; // Reset so activateTimerHooks() can run
        activateTimerHooks();
        startVarKilling();

        // Notify content script
        try {
            window.dispatchEvent(new CustomEvent('killurl-reactivated'));
        } catch (e) { /* ignore */ }
    }

    // ===== VARIABLE KILLING =====

    function killCountdownVars() {
        if (deactivated) return;
        COUNTDOWN_VAR_NAMES.forEach(varName => {
            try {
                if (typeof window[varName] !== 'undefined' && typeof window[varName] === 'number' && window[varName] > 0) {
                    log(`Zeroed variable: ${varName} = ${window[varName]} → 0`);
                    window[varName] = 0;
                }
            } catch (e) { /* ignore */ }
        });
    }

    function startVarKilling() {
        if (varKillInterval || deactivated) return;
        killCountdownVars();
        varKillInterval = _origSetInterval(killCountdownVars, 200);

        COUNTDOWN_VAR_NAMES.forEach(varName => {
            try { interceptProperty(window, varName); } catch (e) { /* skip */ }
        });
    }

    function interceptProperty(obj, prop) {
        if (deactivated) return;
        let _value = obj[prop];
        try {
            Object.defineProperty(obj, prop, {
                get() { return deactivated ? _value : 0; },
                set(v) {
                    if (!deactivated && typeof v === 'number' && v > 1) {
                        log(`Intercepted ${prop} = ${v} → 0`);
                        _value = 0;
                    } else {
                        _value = v;
                    }
                },
                configurable: true
            });
        } catch (e) { /* skip */ }
    }

    // ===== EVENT LISTENERS =====

    // Content script can also trigger activation (for domains not in our list)
    window.addEventListener('killurl-activate', () => {
        if (deactivated) return;
        if (isSecurityURL()) return;
        log('Activation event received');
        activateTimerHooks();
        startVarKilling();
    });

    // Content script sends the aggressive mode setting
    window.addEventListener('killurl-set-aggressive', (e) => {
        aggressiveMode = !!e.detail?.enabled;
        log('Aggressive mode set to:', aggressiveMode);
        // If already deactivated and aggressive mode just turned on, start watching
        if (aggressiveMode && deactivated && !reactivationWatcher && !isActualChallengeFrame()) {
            startReactivationWatcher();
        }
    });

    // Force skip — clear ALL timers + activate if not already
    window.addEventListener('killurl-force-skip', () => {
        if (hasSecurityMarkers() && !aggressiveMode) {
            log('Security page — refusing force-skip (aggressive mode off)');
            window.dispatchEvent(new CustomEvent('killurl-skip-blocked', {
                detail: { reason: 'security-page' }
            }));
            return;
        }

        if (hasSecurityMarkers() && aggressiveMode) {
            log('Aggressive mode: forcing skip despite security markers');
        }

        log('Force skip triggered');
        deactivated = false; // Re-enable if somehow deactivated

        if (!activated) {
            activateTimerHooks();
        }

        // 1. Zero countdown variables FIRST (before firing callbacks)
        killCountdownVars();

        // 2. Fire tracked interval callbacks one last time
        //    They'll see counter=0 and run their "show button" logic
        log(`Firing ${trackedIntervals.size} tracked interval callbacks...`);
        for (const [id, { callback, args }] of trackedIntervals) {
            try {
                callback.call(window, ...(args || []));
            } catch (e) {
                // Callback failed, that's OK
            }
        }

        // 3. Wait for untracked intervals (set before hooks) to fire naturally
        //    They'll see zeroed variables and run their "show button" logic
        _origSetTimeout(() => {
            // Now clear all timer IDs
            for (let i = 1; i < 99999; i++) {
                _origClearTimeout(i);
                _origClearInterval(i);
            }
            trackedIntervals.clear();
            log('All timers cleared after callback flush');
        }, 1500);

        startVarKilling();

        window.dispatchEvent(new CustomEvent('killurl-skip-done'));
    });

    // ===== AUTO-ACTIVATION ON KNOWN DOMAINS =====
    // This runs SYNCHRONOUSLY at document_start, BEFORE any page scripts

    if (isSecurityURL()) {
        log('Security URL detected — staying dormant');
    } else if (isKnownDomain()) {
        log(`Known shortener domain: ${window.location.hostname} — auto-activating`);
        activateTimerHooks();
        startVarKilling();
    } else {
        log('Unknown domain — dormant (waiting for activation)');
    }

    // ===== AUTO-ACTIVATE DRM BYPASS ON STREAMING DOMAINS =====
    // CRITICAL: This hooks EME IMMEDIATELY at document_start, BEFORE the player initializes
    // On streaming domains, we always hook EME (the hook checks settings before modifying)
    if (isStreamingDomain()) {
        console.log('[KillURL] 🎬 Streaming domain detected:', window.location.hostname, '— hooking EME at document_start');
        // Preemptively enable and activate — content.js will confirm settings shortly
        // If settings say disabled, the hook will pass through unmodified
        drmBypassEnabled = true; // Assume enabled until content.js says otherwise
        activateDRMBypass();
    }

    // ===== POST-DOM SECURITY CHECK =====
    // If we auto-activated but it turns out to be a Cloudflare challenge page,
    // DEACTIVATE and restore original timer functions

    window.addEventListener('DOMContentLoaded', () => {
        if (activated && hasSecurityMarkers()) {
            log('Cloudflare challenge detected AFTER activation — deactivating!');
            deactivateTimerHooks(); // Will start reactivation watcher if aggressive mode is on
            window.dispatchEvent(new CustomEvent('killurl-security-page', {
                detail: { aggressiveWatching: aggressiveMode }
            }));
        }
    });

    window.addEventListener('load', () => {
        if (activated && !deactivated && hasSecurityMarkers()) {
            log('Cloudflare challenge detected on load — deactivating!');
            deactivateTimerHooks(); // Will start reactivation watcher if aggressive mode is on
            window.dispatchEvent(new CustomEvent('killurl-security-page', {
                detail: { aggressiveWatching: aggressiveMode }
            }));
        }
    });

})();
