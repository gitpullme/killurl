// KillURL Content Script (ISOLATED world)
// Runs on every page to detect URL shortener countdown pages and provide bypass functionality
// Works alongside injector.js (MAIN world) which handles timer interception
//
// IMPORTANT DESIGN PRINCIPLE:
// - DETECTION is always active (scanning for countdowns)
// - SKIPPING (clicking buttons, killing timers) ONLY happens when:
//   1. User clicks "Skip Countdown" in the popup, OR
//   2. User has explicitly enabled "Auto-Skip" in settings AND page is a KNOWN shortener
// - NEVER interfere with Cloudflare/captcha/security pages

(function () {
    'use strict';

    // ===== STATE =====
    let isShortenerPage = false;
    let isKnownShortener = false; // Confirmed via background domain list
    let isSecurityPage = false; // Cloudflare/captcha detected
    let destinationUrl = null;
    let countdownDetected = false;
    let settings = {};
    let skipAttempted = false;
    let continuousScanner = null;
    let scanCount = 0;
    let injectorActivated = false;

    // ===== SECURITY PAGE DETECTION =====
    // These pages must NEVER be interfered with

    function checkSecurityPage() {
        const url = window.location.href.toLowerCase();
        const hostname = window.location.hostname.toLowerCase();

        // Cloudflare domains
        if (hostname.includes('challenges.cloudflare.com')) return true;
        if (url.includes('/cdn-cgi/') && url.includes('challenge')) return true;

        // Captcha domains
        if (hostname.includes('google.com') && url.includes('recaptcha')) return true;
        if (hostname.includes('recaptcha.net')) return true;
        if (hostname.includes('hcaptcha.com')) return true;

        return false;
    }

    function checkSecurityPageDOM() {
        try {
            const html = document.documentElement?.innerHTML || '';

            // Cloudflare challenge HTML markers (very specific element IDs/classes)
            if (html.includes('id="cf-challenge-running"') ||
                html.includes('id="challenge-running"') ||
                html.includes('cf-turnstile-wrapper') ||
                html.includes('id="challenge-form"') ||
                html.includes('id="challenge-stage"') ||
                html.includes('cf-chl-widget')) {
                return true;
            }

            // Cloudflare JS challenge scripts
            if (html.includes('/cdn-cgi/challenge-platform/')) {
                return true;
            }

            const bodyText = document.body?.textContent || '';

            // Very specific Cloudflare verification text (require BOTH text + CF HTML markers)
            if (bodyText.includes('Performing security verification') &&
                bodyText.includes('security service') && html.includes('cf-')) {
                return true;
            }
            if (bodyText.includes('DDoS protection by') && bodyText.includes('Cloudflare')) {
                return true;
            }
            if (bodyText.includes('Just a moment...') && html.includes('cf-challenge')) {
                return true;
            }

        } catch (e) { /* ignore */ }
        return false;
    }

    // ===== TEXT PATTERNS (for DETECTION only, not auto-action) =====

    const COUNTDOWN_TEXT_PATTERNS = [
        /please wait\s*\d*/i,
        /wait\s*\d+\s*second/i,
        /\d+\s*seconds?\s*remaining/i,
        /\d+\s*seconds?\s*left/i,
        /generating\s*(your\s*)?link/i,
        /preparing\s*(your\s*)?(link|download|file)/i,
        /your\s*link\s*(is\s*)?(being\s*)?generat/i,
        /link\s*will\s*(be\s*)?ready/i,
        /loading\s*link/i,
        /processing\s*link/i,
        /scroll\s*down\s*to\s*continue/i,
        /scroll\s*down\s*to\s*(get|see|view|access)/i,
        /scroll\s*to\s*continue/i,
        /click\s*(here\s*)?to\s*continue/i,
        /click\s*(the\s*)?button\s*below/i,
        /your\s*link\s*is\s*ready/i,
        /link\s*ready/i,
        /your\s*download\s*is\s*ready/i,
        /you\s*will\s*be\s*redirected/i,
        /redirecting\s*in/i,
        /skip\s*(this\s*)?ad/i,
        /wait\s*for\s*\d+/i,
        /timer/i,
        /countdown/i,
    ];

    const BUTTON_TEXT_PATTERNS = [
        /^continue$/i,
        /^skip$/i,
        /^skip\s*ad$/i,
        /^get\s*link$/i,
        /^go\s*to\s*(link|download|url|page|website)/i,
        /^proceed$/i,
        /^click\s*here$/i,
        /^click\s*here\s*to\s*continue$/i,
        /^download$/i,
        /^download\s*now$/i,
        /^download\s*link$/i,
        /^go\s*to\s*link$/i,
        /^visit\s*(link|page|site|url)$/i,
        /^get\s*download\s*link$/i,
        /^generate\s*(download\s*)?link$/i,
        /^access\s*link$/i,
        /^open\s*link$/i,
        /^free\s*download$/i,
        /^direct\s*download$/i,
        /scroll\s*down\s*to\s*continue/i,
        /continue\s*to\s*/i,
        /go\s*to\s*destination/i,
        /get\s*your\s*link/i,
        /get\s*link/i,
        /getlink/i,
    ];

    // ===== ELEMENT SELECTORS =====

    const COUNTDOWN_SELECTORS = [
        '#countdown', '#timer', '#count', '#counter', '#seconds',
        '.countdown', '.timer', '.count', '.counter', '.seconds',
        '[id*="countdown"]', '[id*="timer"]', '[id*="count"]',
        '[class*="countdown"]', '[class*="timer"]',
        '#wait', '.wait', '#loading-time', '.loading-time',
        '#second', '.second', '#sec', '.sec',
        '#wpsafe-timer', '#wpsafe-countdown', '.wpsafe-timer',
        '#wpsafelink-countdown', '.wpsafelink-countdown',
        '#sTimer', '#short_timer', '.short_timer',
        '#scroll-timer', '.scroll-timer',
        '.progress-bar', '#progress-bar', '.progress', '#progress',
        '[role="progressbar"]',
    ];

    const DESTINATION_SELECTORS = [
        'a#skip', 'a.skip', 'a#continue', 'a.continue',
        'a#go-link', 'a.go-link', 'a#getlink', 'a.getlink', 'a#get-link',
        'a#btn-main', 'a.btn-main',
        'a#land-btn', 'a.land-btn',
        'a[href*="?go="]', 'a[href*="?url="]', 'a[href*="?link="]',
        'a[href*="?r="]', 'a[href*="?redirect="]', 'a[href*="?out="]',
        'a[href*="/go/"]', 'a[href*="/out/"]', 'a[href*="/redirect/"]',
        'a[href*="/link/"]', 'a[href*="/get/"]',
        'a#downloadButton', 'a.downloadButton', 'a#download-btn',
        'a.download-btn', 'a.download-link', 'a#download-link',
        'a.btn-success', 'a.btn-primary', 'a.btn-info',
        'button#continue', 'button.continue',
        'button#skip', 'button.skip',
        'button#getlink', 'button.getlink', 'button#get-link',
        '#btn-main a', '.btn-main a',
        '#wpsafe-link a', '.wpsafe-link a',
        '#wpsafe-generate a',
        '#download a', '.download a',
        '#link-box a', '.link-box a',
        '#final-link a', '.final-link a',
        // earnbox.in specific selectors
        'a.btn.btn-primary', 'button.btn.btn-primary',
        'a.btn.btn-success', 'button.btn.btn-success',
        '.earnbox-link a', '#earnbox-link a',
    ];

    const HIDDEN_DURING_COUNTDOWN = [
        '#skip', '.skip', '#continue', '.continue',
        '#go-link', '.go-link', '#getlink', '.getlink',
        '#btn-main', '.btn-main',
        '#download', '.download',
        '#land-btn', '.land-btn',
        '#wpsafe-link', '.wpsafe-link',
        '#wpsafe-generate', '.wpsafe-generate',
        '#scroll-to-continue', '.scroll-to-continue',
        '#final-link', '.final-link',
        '#result-link', '.result-link',
        '#link-box', '.link-box',
        '#continue-btn', '.continue-btn',
        '#skip-btn', '.skip-btn',
    ];

    // ===== INITIALIZATION =====

    function ensureInjectorLoaded() {
        try {
            const pageWindow = typeof window.wrappedJSObject !== 'undefined' ? window.wrappedJSObject : window;
            if (!pageWindow.__killurl_injector_loaded) {
                const api = typeof browser !== 'undefined' && browser.runtime ? browser : chrome;
                const script = document.createElement('script');
                script.src = api.runtime.getURL('content/injector.js');
                script.onload = function () {
                    this.remove();
                };
                (document.head || document.documentElement).appendChild(script);
                console.log('[KillURL] Injected injector.js into MAIN world via DOM fallback');
            }
        } catch (e) {
            console.error('[KillURL] Failed to ensure injector script loaded:', e);
        }
    }

    async function init() {
        ensureInjectorLoaded();

        // Early security check
        if (checkSecurityPage()) {
            isSecurityPage = true;
            console.log('[KillURL] Security page detected');
            // Don't return yet — load settings first to check aggressiveMode
        }

        try {
            settings = await chrome.runtime.sendMessage({ type: 'GET_SETTINGS' });
        } catch (e) {
            settings = {};
        }

        // Pass aggressive mode setting to MAIN world injector
        try {
            window.dispatchEvent(new CustomEvent('killurl-set-aggressive', {
                detail: { enabled: !!settings.aggressiveMode }
            }));
        } catch (e) { /* ignore */ }

        // Pass DRM bypass setting to MAIN world injector
        // This MUST happen as early as possible — injector.js hooks EME at document_start
        // and needs to know if the bypass is enabled
        try {
            window.dispatchEvent(new CustomEvent('killurl-enable-drm-bypass', {
                detail: { enabled: !!settings.screenShareDRM }
            }));
            if (settings.screenShareDRM) {
                console.log('[KillURL] DRM screen share bypass setting sent to MAIN world: ENABLED');
            }
        } catch (e) { /* ignore */ }

        // If security page detected early and aggressive mode is OFF, bail out
        if (isSecurityPage && !settings.aggressiveMode) {
            console.log('[KillURL] Security page — all actions disabled (aggressive mode off)');
            return;
        }

        // Listen for events from MAIN world injector
        window.addEventListener('killurl-timer-intercepted', (e) => {
            console.log('[KillURL] Timer intercepted by injector:', e.detail);
            if (!countdownDetected) {
                countdownDetected = true;
                isShortenerPage = true;
                notifyStatus();
            }
        });

        window.addEventListener('killurl-url-found', (e) => {
            if (e.detail?.url && isValidDestination(e.detail.url)) {
                destinationUrl = e.detail.url;
                try { chrome.runtime.sendMessage({ type: 'FOUND_DESTINATION', url: destinationUrl }); } catch (err) { /* */ }
            }
        });

        window.addEventListener('killurl-skip-done', () => {
            console.log('[KillURL] Skip completed — revealing elements');
            revealHiddenElements();
            forceEnableButtons();
        });

        window.addEventListener('killurl-security-page', (e) => {
            console.log('[KillURL] Security page confirmed by injector — disabling');
            isSecurityPage = true;
            stopContinuousScanner();
            if (e.detail?.aggressiveWatching) {
                console.log('[KillURL] Aggressive mode: waiting for CF to complete...');
            }
        });

        window.addEventListener('killurl-reactivated', () => {
            console.log('[KillURL] Aggressive mode: re-activated after CF completion!');
            isSecurityPage = false;
            skipAttempted = false;
            scanCount = 0;
            // Re-start scanning
            detectShortenerPage();
            passiveScan();
            startContinuousScanner();
            notifyStatus();
            maybeAutoSkip();
        });

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', onDOMReady);
        } else {
            onDOMReady();
        }
    }

    function onDOMReady() {
        // Check security page via DOM markers
        if (checkSecurityPageDOM()) {
            isSecurityPage = true;
            if (!settings.aggressiveMode) {
                console.log('[KillURL] Security page (DOM) detected — all actions disabled');
                return;
            }
            console.log('[KillURL] Security page (DOM) detected — aggressive mode, continuing...');
        }

        // DETECTION only — no skipping
        detectShortenerPage();
        setupMutationObserver();
        startContinuousScanner();

        // earnbox.in specific: watch for button changes more aggressively
        const hostname = window.location.hostname.replace(/^www\./, '');
        if (hostname === 'earnbox.in') {
            setupEarnboxWatcher();
        }

        // Auto-remove ad-block walls if enabled
        if (settings.removeAdBlockWalls) {
            // Run multiple times as walls can appear after a delay
            [500, 1500, 3000, 5000].forEach(delay => {
                setTimeout(() => removeAdBlockWalls(), delay);
            });
        }

        // Re-check at intervals
        [500, 1000, 2000, 3000, 5000, 8000].forEach(delay => {
            setTimeout(() => {
                if (isSecurityPage && !settings.aggressiveMode) return;
                // Re-check for security (some pages load CF challenge after a moment)
                if (checkSecurityPageDOM()) {
                    isSecurityPage = true;
                    if (!settings.aggressiveMode) {
                        stopContinuousScanner();
                        return;
                    }
                }
                detectShortenerPage();
                passiveScan();
            }, delay);
        });
    }

    // earnbox.in specific watcher for button appearances
    function setupEarnboxWatcher() {
        console.log('[KillURL] earnbox.in: Setting up button watcher...');
        
        const observer = new MutationObserver((mutations) => {
            for (const mutation of mutations) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    for (const node of mutation.addedNodes) {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            const text = (node.textContent || '').toLowerCase();
                            // Check if a button with relevant text was added
                            if (text.includes('get link') || text.includes('continue') || text.includes('proceed')) {
                                console.log('[KillURL] earnbox.in: New button detected, attempting click...');
                                setTimeout(() => {
                                    clickEarnboxButton();
                                }, 500);
                            }
                        }
                    }
                }
                
                // Watch for style/class changes that might reveal buttons
                if (mutation.type === 'attributes' && (mutation.attributeName === 'style' || mutation.attributeName === 'class')) {
                    const target = mutation.target;
                    if (target.nodeType === Node.ELEMENT_NODE) {
                        const text = (target.textContent || '').toLowerCase();
                        if ((text.includes('get link') || text.includes('continue')) && isVisible(target)) {
                            console.log('[KillURL] earnbox.in: Button became visible, attempting click...');
                            setTimeout(() => {
                                clickEarnboxButton();
                            }, 500);
                        }
                    }
                }
            }
        });

        observer.observe(document.documentElement, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['style', 'class', 'disabled', 'hidden']
        });
    }

    // ===== CONTINUOUS SCANNER (PASSIVE — detection only, no clicking) =====

    function startContinuousScanner() {
        if (continuousScanner) return;

        continuousScanner = setInterval(() => {
            if (isSecurityPage && !settings.aggressiveMode) {
                stopContinuousScanner();
                return;
            }

            scanCount++;
            passiveScan();

            // Stop scanning after 2 minutes
            if (scanCount > 120) {
                stopContinuousScanner();
            }
        }, 1000);
    }

    function stopContinuousScanner() {
        if (continuousScanner) {
            clearInterval(continuousScanner);
            continuousScanner = null;
        }
    }

    // Passive scan — detect only, no clicking or modifying
    function passiveScan() {
        detectCountdownByText();
        detectVisibleContinueButtons();
        findDestinationUrl();
    }

    // ===== TEXT-BASED DETECTION =====

    function detectCountdownByText() {
        if (isSecurityPage && !settings.aggressiveMode) return;
        if (countdownDetected && isShortenerPage) return;

        const bodyText = document.body?.innerText || '';

        for (const pattern of COUNTDOWN_TEXT_PATTERNS) {
            if (pattern.test(bodyText)) {
                console.log(`[KillURL] Countdown detected by text: ${pattern}`);
                countdownDetected = true;
                isShortenerPage = true;
                notifyStatus();
                maybeAutoSkip();
                return;
            }
        }

        // Check for prominent countdown numbers (font ≥ 20px, value 1-60)
        const elements = document.querySelectorAll('div, span, p, h1, h2, h3, h4, h5, h6, strong, b');
        for (const el of elements) {
            if (!isVisible(el)) continue;
            const text = el.textContent.trim();
            if (/^\d{1,2}$/.test(text)) {
                const num = parseInt(text);
                if (num >= 1 && num <= 60) {
                    try {
                        const fontSize = parseFloat(window.getComputedStyle(el).fontSize);
                        if (fontSize >= 20) {
                            console.log(`[KillURL] Countdown number detected: ${num} (${fontSize}px)`);
                            countdownDetected = true;
                            isShortenerPage = true;
                            notifyStatus();
                            maybeAutoSkip();
                            return;
                        }
                    } catch (e) { /* ignore */ }
                }
            }
        }
    }

    // Detect visible continue/skip buttons (for popup status display)
    function detectVisibleContinueButtons() {
        const clickables = document.querySelectorAll('a, button, input[type="submit"], input[type="button"]');
        for (const el of clickables) {
            if (!isVisible(el)) continue;
            const text = (el.textContent || el.value || '').trim();
            for (const pattern of BUTTON_TEXT_PATTERNS) {
                if (pattern.test(text)) {
                    const href = el.getAttribute('href');
                    if (href && href !== '#' && !href.startsWith('javascript:') && isValidDestination(href)) {
                        destinationUrl = href;
                        try { chrome.runtime.sendMessage({ type: 'FOUND_DESTINATION', url: destinationUrl }); } catch (e) { /* */ }
                    }
                    return;
                }
            }
        }
    }

    // ===== AUTO-SKIP LOGIC =====
    // Only auto-skips if BOTH conditions are met:
    // 1. settings.autoSkip is true (user explicitly enabled it)
    // 2. Page is a KNOWN shortener (confirmed by background domain list)

    function maybeAutoSkip() {
        if (isSecurityPage && !settings.aggressiveMode) return;
        if (skipAttempted) return;
        if (!settings.autoSkip) return;

        // On known shorteners: always auto-skip
        // On unknown domains: only auto-skip if aggressive mode is ON AND a countdown is detected
        if (!isKnownShortener) {
            if (!settings.aggressiveMode || !countdownDetected) return;
            console.log('[KillURL] Auto-skip triggered on unknown site (aggressive mode + countdown detected)');
        } else {
            console.log('[KillURL] Auto-skip triggered on known shortener' +
                (isSecurityPage ? ' (aggressive mode)' : ''));
        }

        skipAttempted = true;

        // Check if this is earnbox.in - needs more aggressive retry strategy
        const hostname = window.location.hostname.replace(/^www\./, '');
        const isEarnbox = hostname === 'earnbox.in';

        // Schedule multiple skip attempts with increasing delays
        // Early attempts use gentle skip (DOM only, don't kill page timers)
        // Later attempts use full skip (nuclear option) after page has loaded
        const baseDelay = settings.skipDelay || 500;
        
        let attempts;
        if (isEarnbox) {
            // earnbox.in needs more attempts with longer delays
            attempts = [
                { delay: baseDelay, gentle: true },  // ~0.5s
                { delay: baseDelay + 1500, gentle: true },  // ~2s
                { delay: baseDelay + 3000, gentle: true },  // ~3.5s
                { delay: baseDelay + 5000, gentle: true },  // ~5.5s
                { delay: baseDelay + 7000, gentle: false },  // ~7.5s — full skip
                { delay: baseDelay + 10000, gentle: false },  // ~10.5s — full skip
                { delay: baseDelay + 13000, gentle: false },  // ~13.5s — full skip
                { delay: baseDelay + 16000, gentle: false },  // ~16.5s — full skip
                { delay: baseDelay + 20000, gentle: false },  // ~20.5s — full skip (final)
            ];
        } else {
            attempts = [
                { delay: baseDelay, gentle: true },  // ~0.5s
                { delay: baseDelay + 1500, gentle: true },  // ~2s
                { delay: baseDelay + 3000, gentle: true },  // ~3.5s
                { delay: baseDelay + 5000, gentle: true },  // ~5.5s
                { delay: baseDelay + 8000, gentle: false },  // ~8.5s — full skip
                { delay: baseDelay + 12000, gentle: false },  // ~12.5s — full skip
            ];
        }

        attempts.forEach(({ delay, gentle }, index) => {
            setTimeout(() => {
                console.log(`[KillURL] Auto-skip attempt ${index + 1}/${attempts.length} (${gentle ? 'gentle' : 'full'})`);
                if (gentle) {
                    executeGentleSkip();
                } else {
                    executeSkip();
                }
            }, delay);
        });
    }

    // ===== DETECT SHORTENER (domain check) =====

    function detectShortenerPage() {
        if (isSecurityPage && !settings.aggressiveMode) return;
        const hostname = window.location.hostname.replace(/^www\./, '');

        chrome.runtime.sendMessage(
            { type: 'CHECK_SHORTENER', hostname },
            (response) => {
                if (response?.isShortener) {
                    isKnownShortener = true;
                    isShortenerPage = true;
                    notifyStatus();
                    maybeAutoSkip();
                    return;
                }

                // Heuristic detection (selector/text based)
                if (detectCountdownElements()) {
                    isShortenerPage = true;
                    notifyStatus();
                    // Auto-skip on unknown domains only with aggressive mode (checked inside maybeAutoSkip)
                    maybeAutoSkip();
                }
            }
        );
    }

    function detectCountdownElements() {
        for (const selector of COUNTDOWN_SELECTORS) {
            try {
                const el = document.querySelector(selector);
                if (el && isVisible(el)) {
                    const text = el.textContent.trim();
                    if (/\d/.test(text) && text.length < 30) {
                        countdownDetected = true;
                        return true;
                    }
                }
            } catch (e) { /* skip */ }
        }

        for (const selector of HIDDEN_DURING_COUNTDOWN) {
            try {
                const el = document.querySelector(selector);
                if (el && !isVisible(el)) {
                    countdownDetected = true;
                    return true;
                }
            } catch (e) { /* skip */ }
        }

        const metaRefresh = document.querySelector('meta[http-equiv="refresh"]');
        if (metaRefresh) {
            const content = metaRefresh.getAttribute('content') || '';
            const urlMatch = content.match(/url=(.+)/i);
            if (urlMatch) {
                destinationUrl = urlMatch[1].trim().replace(/['"]/g, '');
                return true;
            }
        }

        return false;
    }

    function notifyStatus() {
        try {
            chrome.runtime.sendMessage({ type: 'PAGE_STATUS', detected: true });
        } catch (e) { /* ignore */ }
        findDestinationUrl();
    }

    // ===== EXECUTE GENTLE SKIP (auto-skip — DOM only, doesn't kill timers) =====
    // Safe to run early — won't break page loading

    function executeGentleSkip() {
        if (isSecurityPage && !settings.aggressiveMode) return;

        console.log('[KillURL] Gentle skip — DOM manipulation only...');

        // DOM manipulation — reveal buttons, remove overlays
        revealHiddenElements();
        removeOverlays();
        handleProgressBars();
        forceEnableButtons();
        findDestinationUrl();

        // Try clicking continue buttons
        setTimeout(() => {
            clickContinueButton();
            findDestinationUrl();
        }, 300);
    }

    // ===== EXECUTE SKIP (manual click or escalated auto-skip — full nuclear) =====
    // This clears ALL timers and zeros variables — can break page loading if run too early

    function executeSkip() {
        if (isSecurityPage && !settings.aggressiveMode) {
            console.log('[KillURL] Skipping blocked — security page (aggressive mode off)');
            return;
        }

        if (isSecurityPage && settings.aggressiveMode) {
            console.log('[KillURL] Aggressive mode: forcing skip despite security page detection');
        }

        console.log('[KillURL] Executing skip...');

        // 1. Activate the MAIN world injector (hooks timers)
        if (!injectorActivated) {
            injectorActivated = true;
            window.dispatchEvent(new CustomEvent('killurl-activate'));
        }

        // 2. Force-skip in MAIN world (clears all timers, zeros variables)
        window.dispatchEvent(new CustomEvent('killurl-force-skip'));

        // Also request background to inject skip script (belt + suspenders)
        try { chrome.runtime.sendMessage({ type: 'INJECT_SKIP_SCRIPT' }); } catch (e) { /* */ }

        // 3. DOM manipulation — reveal buttons, remove overlays
        revealHiddenElements();
        removeOverlays();
        handleProgressBars();
        forceEnableButtons();

        // 4. Try clicking continue buttons
        setTimeout(() => {
            clickContinueButton();
            findDestinationUrl();
        }, 200);

        // 5. Retry at intervals (more retries for earnbox.in)
        const hostname = window.location.hostname.replace(/^www\./, '');
        const isEarnbox = hostname === 'earnbox.in';
        
        const retryDelays = isEarnbox 
            ? [500, 1000, 1500, 2000, 3000, 4000, 5000, 7000, 10000, 13000, 16000] 
            : [500, 1000, 2000, 3000];
            
        retryDelays.forEach(delay => {
            setTimeout(() => {
                revealHiddenElements();
                forceEnableButtons();
                clickContinueButton();
                findDestinationUrl();
            }, delay);
        });
    }

    // ===== FIND DESTINATION URL =====

    function findDestinationUrl() {
        // 1. Known selector patterns
        for (const selector of DESTINATION_SELECTORS) {
            try {
                const el = document.querySelector(selector);
                if (el) {
                    const href = el.getAttribute('href') || el.dataset?.url || el.dataset?.href;
                    if (href && isValidDestination(href)) {
                        destinationUrl = href;
                        try { chrome.runtime.sendMessage({ type: 'FOUND_DESTINATION', url: destinationUrl }); } catch (e) { /* */ }
                        return;
                    }
                }
            } catch (e) { /* skip */ }
        }

        // 2. Text-based link scan
        const allLinks = document.querySelectorAll('a[href]');
        for (const link of allLinks) {
            const href = link.getAttribute('href');
            if (!href || href === '#' || href.startsWith('javascript:')) continue;

            const text = (link.textContent || '').trim();
            if (!text) continue;

            for (const pattern of BUTTON_TEXT_PATTERNS) {
                if (pattern.test(text)) {
                    if (isValidDestination(href)) {
                        destinationUrl = href;
                        try { chrome.runtime.sendMessage({ type: 'FOUND_DESTINATION', url: destinationUrl }); } catch (e) { /* */ }
                        return;
                    }
                    break;
                }
            }

            const lowerText = text.toLowerCase();
            if (lowerText.includes('continue') || lowerText.includes('skip') ||
                lowerText.includes('get link') || lowerText.includes('download') ||
                lowerText.includes('go to') || lowerText.includes('scroll down')) {
                if (isValidDestination(href)) {
                    destinationUrl = href;
                    try { chrome.runtime.sendMessage({ type: 'FOUND_DESTINATION', url: destinationUrl }); } catch (e) { /* */ }
                    return;
                }
            }
        }

        // 3. Scripts
        const scripts = document.querySelectorAll('script:not([src])');
        for (const script of scripts) {
            const content = script.textContent;
            if (!content || content.length < 10) continue;

            const urlPatterns = [
                /(?:var|let|const)\s+(?:url|link|redirect|destination|target|go|href|finalUrl|final_url|redirectUrl|redirect_url)\s*=\s*['"](https?:\/\/[^'"]+)['"]/gi,
                /window\.location(?:\.href)?\s*=\s*['"](https?:\/\/[^'"]+)['"]/gi,
                /location\.replace\(\s*['"](https?:\/\/[^'"]+)['"]\s*\)/gi,
                /atob\(\s*['"]([A-Za-z0-9+/=]{20,})['"]\s*\)/gi,
            ];

            for (const pattern of urlPatterns) {
                let match;
                while ((match = pattern.exec(content)) !== null) {
                    let url = match[1];
                    if (/^[A-Za-z0-9+/=]+$/.test(url) && url.length > 20) {
                        try { url = atob(url); } catch (e) { /* */ }
                    }
                    if (url.startsWith('http') && isValidDestination(url)) {
                        destinationUrl = url;
                        try { chrome.runtime.sendMessage({ type: 'FOUND_DESTINATION', url: destinationUrl }); } catch (e) { /* */ }
                        return;
                    }
                }
            }
        }

        // 4. Data attributes
        const elementsWithData = document.querySelectorAll(
            '[data-url], [data-href], [data-link], [data-redirect], [data-target]'
        );
        for (const el of elementsWithData) {
            const url = el.dataset.url || el.dataset.href || el.dataset.link ||
                el.dataset.redirect || el.dataset.target;
            if (url && isValidDestination(url)) {
                destinationUrl = url;
                try { chrome.runtime.sendMessage({ type: 'FOUND_DESTINATION', url: destinationUrl }); } catch (e) { /* */ }
                return;
            }
        }
    }

    // ===== DOM MODIFICATION (only during skip) =====

    function forceShow(el) {
        if (!el) return;
        el.style.setProperty('display', 'block', 'important');
        el.style.setProperty('visibility', 'visible', 'important');
        el.style.setProperty('opacity', '1', 'important');
        el.style.setProperty('pointer-events', 'auto', 'important');
        el.style.setProperty('height', 'auto', 'important');
        el.style.setProperty('max-height', 'none', 'important');
        el.style.setProperty('overflow', 'visible', 'important');
        el.style.setProperty('z-index', '99999', 'important');
        el.style.setProperty('transform', 'none', 'important');
        el.style.setProperty('clip', 'auto', 'important');
        el.style.setProperty('clip-path', 'none', 'important');
        el.removeAttribute('disabled');
        el.removeAttribute('aria-disabled');
        el.removeAttribute('aria-hidden');
        el.classList.remove('hidden', 'd-none', 'invisible', 'hide', 'disabled', 'none', 'ng-hide');
    }

    function revealHiddenElements() {
        const allSelectors = [...HIDDEN_DURING_COUNTDOWN, ...DESTINATION_SELECTORS];
        const processed = new Set();

        for (const selector of allSelectors) {
            try {
                document.querySelectorAll(selector).forEach(el => {
                    if (processed.has(el)) return;
                    processed.add(el);
                    forceShow(el);
                });
            } catch (e) { /* skip */ }
        }

        // Also scan buttons/links with relevant text
        document.querySelectorAll('a, button, input[type="submit"], input[type="button"], [role="button"]').forEach(el => {
            const text = (el.textContent || el.value || '').toLowerCase().trim();
            if (!text) return;

            const isRelevant =
                text.includes('continue') || text.includes('skip') ||
                text.includes('get link') || text.includes('go to') ||
                text.includes('download') || text.includes('proceed') ||
                text.includes('scroll down') || text.includes('next') ||
                text.includes('click here');

            if (isRelevant && !isVisible(el)) {
                forceShow(el);
                // Walk up parents
                let parent = el.parentElement;
                let depth = 0;
                while (parent && depth < 5) {
                    if (!isVisible(parent)) forceShow(parent);
                    parent = parent.parentElement;
                    depth++;
                }
            }
        });
    }

    function forceEnableButtons() {
        document.querySelectorAll('a, button, input[type="submit"], input[type="button"]').forEach(el => {
            const text = (el.textContent || el.value || '').toLowerCase().trim();
            if (!text) return;

            const isRelevant =
                text.includes('continue') || text.includes('skip') ||
                text.includes('get link') || text.includes('download') ||
                text.includes('go to') || text.includes('proceed') ||
                text.includes('scroll down') || text.includes('next');

            if (isRelevant) {
                if (el.disabled || el.getAttribute('aria-disabled') === 'true') {
                    el.disabled = false;
                    el.removeAttribute('aria-disabled');
                    el.removeAttribute('disabled');
                    el.style.setProperty('pointer-events', 'auto', 'important');
                    el.style.setProperty('opacity', '1', 'important');
                }

                // Fix onclick handlers: extract URL instead of removing the handler
                const onclick = el.getAttribute('onclick') || '';
                if (onclick) {
                    // Extract any URL from the onclick handler
                    const urlMatch = onclick.match(/(?:window\.)?location(?:\.href)?\s*=\s*['"]([^'"]+)['"]/i) ||
                        onclick.match(/location\.replace\(['"]([^'"]+)['"]\)/i) ||
                        onclick.match(/window\.open\(['"]([^'"]+)['"]/);
                    if (urlMatch && urlMatch[1]) {
                        // Preserve the URL as href so direct navigation works
                        if (el.tagName === 'A' && (!el.getAttribute('href') || el.getAttribute('href') === '#' || el.getAttribute('href') === 'javascript:void(0)')) {
                            el.setAttribute('href', urlMatch[1]);
                        }
                    }
                    // Remove only the "return false" part, keep the rest of the handler
                    if (onclick.includes('return false') || onclick.includes('return !')) {
                        const fixed = onclick.replace(/;?\s*return\s+(false|![a-z01])\s*;?/gi, ';');
                        el.setAttribute('onclick', fixed);
                    }
                }
            }
        });
    }

    function removeOverlays() {
        const overlaySelectors = [
            '#overlay', '.overlay', '#ad-overlay', '.ad-overlay',
            '.modal-backdrop', '#modal-backdrop',
            '.ad-container', '#ad-container',
            '.splash-overlay', '#splash-overlay',
            '.blocker', '#blocker',
        ];

        overlaySelectors.forEach(selector => {
            try {
                document.querySelectorAll(selector).forEach(el => {
                    if (el.querySelector('a[href], button, input[type="submit"]')) {
                        el.style.setProperty('background', 'transparent', 'important');
                    } else {
                        el.style.setProperty('display', 'none', 'important');
                    }
                });
            } catch (e) { /* skip */ }
        });

        document.body.style.setProperty('overflow', 'auto', 'important');
        document.documentElement.style.setProperty('overflow', 'auto', 'important');
    }

    function handleProgressBars() {
        document.querySelectorAll('.progress-bar, [role="progressbar"], .progress').forEach(el => {
            el.style.setProperty('width', '100%', 'important');
            el.style.setProperty('transition', 'none', 'important');
            el.setAttribute('aria-valuenow', '100');
        });
    }

    function clickContinueButton() {
        // Site-specific handlers
        const hostname = window.location.hostname.replace(/^www\./, '');
        
        // earnbox.in specific handling
        if (hostname === 'earnbox.in') {
            const found = clickEarnboxButton();
            // If earnbox handler didn't find anything, fall through to generic handler
            if (found) return;
            console.log('[KillURL] earnbox.in: Falling back to generic handler...');
        }

        // Try to click or navigate via known button selectors
        const buttonSelectors = [
            '#skip', '.skip', 'a#skip', 'a.skip',
            '#continue', '.continue', 'a#continue', 'a.continue',
            '#go-link', '.go-link', 'a#go-link', 'a.go-link',
            '#getlink', '.getlink', 'a#getlink', 'a.getlink',
            '#btn-main', '.btn-main', 'a#btn-main', 'a.btn-main',
            '#land-btn', '.land-btn',
            '#wpsafe-link a', '.wpsafe-link a',
            '#wpsafe-generate a',
            '#download a', '.download a',
            '#scroll-to-continue', '.scroll-to-continue',
            '#continue-btn', '.continue-btn',
            '#skip-btn', '.skip-btn',
        ];

        for (const selector of buttonSelectors) {
            try {
                const btn = document.querySelector(selector);
                if (btn && isVisible(btn) && !btn.disabled) {
                    navigateOrClick(btn);
                    return;
                }
            } catch (e) { /* skip */ }
        }

        // Fallback: text-based click
        const clickables = document.querySelectorAll('a, button, input[type="submit"], input[type="button"]');
        for (const el of clickables) {
            if (!isVisible(el) || el.disabled) continue;
            const text = (el.textContent || el.value || '').trim();
            for (const pattern of BUTTON_TEXT_PATTERNS) {
                if (pattern.test(text)) {
                    navigateOrClick(el);
                    return;
                }
            }
        }
    }

    // earnbox.in specific button clicking logic
    // earnbox.in has a two-step process:
    // Step 1: Timer countdown → "Get Link" button appears
    // Step 2: After clicking "Get Link" → "Continue" button appears
    function clickEarnboxButton() {
        console.log('[KillURL] earnbox.in: Looking for buttons (Get Link or Continue)...');
        
        // Strategy 1: Look for buttons/links with specific text patterns (check hidden ones too)
        const allClickables = document.querySelectorAll('a, button, input[type="submit"], input[type="button"], [role="button"]');
        for (const el of allClickables) {
            const text = (el.textContent || el.value || '').toLowerCase().trim();
            
            // Check for "Get Link" button (Step 1)
            if (text.includes('get link') || text === 'getlink' || text.includes('get your link')) {
                console.log('[KillURL] earnbox.in: Found "Get Link" button (Step 1):', text, 'visible:', isVisible(el));
                // Force show it and all parents
                forceShow(el);
                let parent = el.parentElement;
                let depth = 0;
                while (parent && depth < 5) {
                    forceShow(parent);
                    parent = parent.parentElement;
                    depth++;
                }
                setTimeout(() => {
                    el.click();
                    console.log('[KillURL] earnbox.in: Clicked "Get Link", waiting for Continue button...');
                    // After clicking Get Link, wait and look for Continue button
                    setTimeout(() => {
                        clickEarnboxButton(); // Recursive call to find Continue button
                    }, 1500);
                }, 500);
                return true;
            }
            
            // Check for "Continue" button (Step 2)
            if (text === 'continue' || text.includes('continue to') || text === 'proceed' || text === 'next') {
                console.log('[KillURL] earnbox.in: Found "Continue" button (Step 2):', text, 'visible:', isVisible(el));
                // Force show it and all parents
                forceShow(el);
                let parent = el.parentElement;
                let depth = 0;
                while (parent && depth < 5) {
                    forceShow(parent);
                    parent = parent.parentElement;
                    depth++;
                }
                setTimeout(() => {
                    navigateOrClick(el);
                    console.log('[KillURL] earnbox.in: Clicked "Continue" button');
                }, 500);
                return true;
            }
        }

        // Strategy 2: Look for primary/success buttons (check hidden ones too)
        const primaryButtons = document.querySelectorAll('.btn-primary, .btn-success, .btn.btn-primary, .btn.btn-success, .btn-info, .btn.btn-block');
        for (const btn of primaryButtons) {
            if (btn.tagName !== 'A' && btn.tagName !== 'BUTTON') continue;
            
            const text = (btn.textContent || '').toLowerCase().trim();
            // Skip if it's clearly not the right button
            if (text.includes('login') || text.includes('sign up') || text.includes('register') || text.includes('submit')) continue;
            
            console.log('[KillURL] earnbox.in: Found primary/success button:', text, 'visible:', isVisible(btn));
            // Force show it and all parents
            forceShow(btn);
            let parent = btn.parentElement;
            let depth = 0;
            while (parent && depth < 5) {
                forceShow(parent);
                parent = parent.parentElement;
                depth++;
            }
            setTimeout(() => {
                btn.click();
                console.log('[KillURL] earnbox.in: Clicked button, checking for next step...');
                // Wait and check if there's another button to click
                setTimeout(() => {
                    clickEarnboxButton();
                }, 1500);
            }, 500);
            return true;
        }

        // Strategy 3: Look for any link/button with destination-like text (check hidden ones too)
        const allLinks = document.querySelectorAll('a[href], button');
        for (const el of allLinks) {
            const text = (el.textContent || '').toLowerCase().trim();
            const href = el.getAttribute('href');
            
            // Look for destination-like text
            if (text && (text.includes('link') || text.includes('continue') || text.includes('proceed') || text.includes('next') || text.includes('skip'))) {
                // Skip navigation links
                if (text.includes('home') || text.includes('about') || text.includes('contact') || text.includes('privacy')) continue;
                
                console.log('[KillURL] earnbox.in: Found potential button/link:', text, href || '(button)', 'visible:', isVisible(el));
                // Force show it and all parents
                forceShow(el);
                let parent = el.parentElement;
                let depth = 0;
                while (parent && depth < 5) {
                    forceShow(parent);
                    parent = parent.parentElement;
                    depth++;
                }
                setTimeout(() => {
                    if (href && href !== '#' && !href.startsWith('javascript:')) {
                        navigateOrClick(el);
                    } else {
                        el.click();
                        // Wait and check for next step
                        setTimeout(() => {
                            clickEarnboxButton();
                        }, 1500);
                    }
                }, 500);
                return true;
            }
        }

        console.log('[KillURL] earnbox.in: No button found yet, will retry...');
        return false;
    }

    function navigateOrClick(el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });

        // Get href from element or its parent link
        let href = el.getAttribute('href');
        if (!href || href === '#' || href.startsWith('javascript:')) {
            // Check data attributes
            href = el.dataset?.url || el.dataset?.href || el.dataset?.link;
        }
        if (!href || href === '#' || href.startsWith('javascript:')) {
            // Check parent <a>
            const parentLink = el.closest('a[href]');
            if (parentLink) {
                const parentHref = parentLink.getAttribute('href');
                if (parentHref && parentHref !== '#' && !parentHref.startsWith('javascript:')) {
                    href = parentHref;
                }
            }
        }
        // Also check onclick for embedded URLs
        if (!href || href === '#' || href.startsWith('javascript:')) {
            const onclick = el.getAttribute('onclick') || '';
            const urlMatch = onclick.match(/(?:window\.)?location(?:\.href)?\s*=\s*['"]([^'"]+)['"]/i) ||
                onclick.match(/location\.replace\(['"]([^'"]+)['"]\)/i);
            if (urlMatch) href = urlMatch[1];
        }

        // First try clicking normally
        setTimeout(() => {
            el.click();

            // If clicking didn't navigate and we have a valid href, navigate directly after a short delay
            if (href && href !== '#' && !href.startsWith('javascript:')) {
                setTimeout(() => {
                    // Check if we're still on the same page (click didn't navigate)
                    if (document.hasFocus()) {
                        console.log('[KillURL] Click did not navigate, using href directly:', href);
                        if (href.startsWith('http') || href.startsWith('/')) {
                            window.location.href = href;
                        }
                    }
                }, 500);
            }
        }, 200);
    }

    // ===== UTILITIES =====

    function isVisible(el) {
        if (!el) return false;
        try {
            const style = window.getComputedStyle(el);
            return style.display !== 'none' &&
                style.visibility !== 'hidden' &&
                parseFloat(style.opacity) > 0 &&
                el.offsetWidth > 0 &&
                el.offsetHeight > 0;
        } catch (e) {
            return false;
        }
    }

    function isValidDestination(url) {
        if (!url) return false;
        url = url.trim();
        if (url.startsWith('/go/') || url.startsWith('/out/') || url.startsWith('/redirect/') || url.startsWith('/link/')) return true;
        if (!url.startsWith('http://') && !url.startsWith('https://')) return false;
        try {
            const destHost = new URL(url).hostname.replace(/^www\./, '');
            const currentHost = window.location.hostname.replace(/^www\./, '');
            return destHost !== currentHost;
        } catch (e) {
            return false;
        }
    }

    // ===== MUTATION OBSERVER (passive — detection only) =====

    function setupMutationObserver() {
        const observer = new MutationObserver((mutations) => {
            if (isSecurityPage && !settings.aggressiveMode) return;

            let shouldScan = false;
            for (const mutation of mutations) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    for (const node of mutation.addedNodes) {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            // Check if CF challenge was injected after load
                            const html = node.innerHTML || '';
                            if (html.includes('cf-challenge') || html.includes('cf-turnstile') || html.includes('challenge-platform')) {
                                isSecurityPage = true;
                                if (!settings.aggressiveMode) {
                                    stopContinuousScanner();
                                    return;
                                }
                            }

                            const text = (node.textContent || '').toLowerCase();
                            if (text.includes('continue') || text.includes('skip') ||
                                text.includes('get link') || text.includes('scroll down') ||
                                text.includes('download') || text.includes('click here')) {
                                shouldScan = true;
                            }
                        }
                    }
                }

                if (mutation.type === 'attributes') {
                    const target = mutation.target;
                    if (mutation.attributeName === 'disabled' || mutation.attributeName === 'style' ||
                        mutation.attributeName === 'class' || mutation.attributeName === 'href') {
                        const text = (target.textContent || '').toLowerCase();
                        if (text.includes('continue') || text.includes('skip') ||
                            text.includes('get link') || text.includes('scroll down')) {
                            shouldScan = true;
                        }
                    }
                }
            }

            if (shouldScan) {
                setTimeout(() => passiveScan(), 100);
            }
        });

        observer.observe(document.documentElement, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['style', 'class', 'disabled', 'href', 'aria-disabled', 'aria-hidden']
        });
    }

    // ===== AD-BLOCK WALL REMOVAL =====

    function removeAdBlockWalls() {
        let removed = 0;

        // Text patterns that identify ad-block detection overlays
        const adblockTextPatterns = [
            /ad\s*block/i,
            /ad\s*blocker/i,
            /adblock/i,
            /please\s*(disable|turn\s*off|deactivate|whitelist|remove)/i,
            /disable\s*(your\s*)?ad/i,
            /turn\s*off\s*(your\s*)?ad/i,
            /deactivate\s*(your\s*)?ad/i,
            /whitelist\s*(this|our)/i,
            /ad\s*blocking\s*(software|extension|plugin)/i,
            /\u0645\u0627\u0646\u0639\s*\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a/i, // Arabic: ad blocker
            /adblocker\s*(detected|enabled|found|active)/i,
            /we\s*detected\s*(an?\s*)?ad/i,
            /you\s*(are|'re)\s*using\s*(an?\s*)?ad/i,
        ];

        // Known ad-block wall selectors (common libraries/plugins)
        const knownSelectors = [
            '#adblock-notice', '.adblock-notice',
            '#adblock-modal', '.adblock-modal',
            '#adblock-overlay', '.adblock-overlay',
            '#adblock-wrapper', '.adblock-wrapper',
            '#ab-message', '.ab-message',
            '#adblockDetect', '.adblockDetect',
            '#adb-enabled', '.adb-enabled',
            '#adblock_message', '.adblock_message',
            '#adblock-popup', '.adblock-popup',
            '#adblock-banner', '.adblock-banner',
            '#adbdetect', '.adbdetect',
            '#blockMsg', '.blockMsg',
            '.adblock-warning', '#adblock-warning',
            '.adblocker-root', '#adblocker-root',
            '.disable-adblock', '#disable-adblock',
            '[id*="adblock"]', '[id*="adbDetect"]',
            '[class*="adblock"]', '[class*="adbDetect"]',
            '[id*="AdBlock"]', '[class*="AdBlock"]',
            '.fc-consent-root', // Funding Choices
        ];

        // 1. Remove by known selectors
        for (const selector of knownSelectors) {
            try {
                document.querySelectorAll(selector).forEach(el => {
                    const text = (el.textContent || '').toLowerCase();
                    if (text.includes('ad') && (text.includes('block') || text.includes('disable'))) {
                        el.remove();
                        removed++;
                    }
                });
            } catch (e) { /* skip */ }
        }

        // 2. Scan all fixed/absolute elements for ad-block text
        const allElements = document.querySelectorAll('*');
        for (const el of allElements) {
            try {
                const style = window.getComputedStyle(el);
                const isOverlay = (style.position === 'fixed' || style.position === 'absolute') &&
                    parseInt(style.zIndex || '0') > 100;
                if (!isOverlay) continue;

                const text = (el.textContent || '').substring(0, 1000); // limit for perf
                let isAdBlockWall = false;
                for (const pattern of adblockTextPatterns) {
                    if (pattern.test(text)) {
                        isAdBlockWall = true;
                        break;
                    }
                }

                if (isAdBlockWall) {
                    el.remove();
                    removed++;
                }
            } catch (e) { /* skip */ }
        }

        // 3. Remove common backdrop/dimmer overlays left behind
        document.querySelectorAll('div, section').forEach(el => {
            try {
                const style = window.getComputedStyle(el);
                if (style.position === 'fixed' &&
                    parseInt(style.zIndex || '0') > 100 &&
                    (style.backgroundColor.includes('rgba') || parseFloat(style.opacity) < 0.9) &&
                    el.children.length === 0 &&
                    (el.textContent || '').trim() === '') {
                    // Empty backdrop overlay — remove it
                    el.remove();
                    removed++;
                }
            } catch (e) { /* skip */ }
        });

        // 4. Restore body scroll
        if (removed > 0) {
            document.body.style.setProperty('overflow', 'auto', 'important');
            document.documentElement.style.setProperty('overflow', 'auto', 'important');
            document.body.style.setProperty('position', 'static', 'important');
            document.body.classList.remove('modal-open', 'no-scroll', 'noscroll', 'overflow-hidden');
            console.log(`[KillURL] Removed ${removed} ad-block wall element(s)`);
        }

        return removed;
    }

    // ===== MESSAGE HANDLER =====

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        switch (message.type) {
            case 'EXECUTE_SKIP':
            case 'DO_SKIP':
                // USER explicitly clicked skip
                executeSkip();
                sendResponse({
                    success: !isSecurityPage || !!settings.aggressiveMode,
                    destinationUrl,
                    isSecurityPage: isSecurityPage && !settings.aggressiveMode,
                    aggressiveMode: !!settings.aggressiveMode
                });
                break;

            case 'SHORTENER_DETECTED':
                isKnownShortener = true;
                isShortenerPage = true;
                if (message.autoSkip) settings.autoSkip = true;
                if (message.autoRedirect) settings.autoRedirect = true;
                notifyStatus();
                maybeAutoSkip();
                sendResponse({ success: true });
                break;

            case 'GET_STATUS':
                sendResponse({
                    isShortenerPage,
                    isKnownShortener,
                    isSecurityPage,
                    aggressiveMode: !!settings.aggressiveMode,
                    countdownDetected,
                    destinationUrl,
                    hostname: window.location.hostname,
                    scanCount
                });
                break;

            case 'DO_REDIRECT':
                if (message.url) {
                    window.location.href = message.url;
                } else if (destinationUrl) {
                    window.location.href = destinationUrl;
                }
                sendResponse({ success: true });
                break;

            case 'REMOVE_ADBLOCK_WALL':
                const wallsRemoved = removeAdBlockWalls();
                sendResponse({ success: true, removed: wallsRemoved });
                break;

            case 'SCAN_PAGE':
                isShortenerPage = false;
                countdownDetected = false;
                destinationUrl = null;
                isSecurityPage = false;
                scanCount = 0;

                // Re-check security
                if (checkSecurityPage() || checkSecurityPageDOM()) {
                    isSecurityPage = true;
                }

                if (!isSecurityPage || settings.aggressiveMode) {
                    detectShortenerPage();
                    passiveScan();
                }

                setTimeout(() => {
                    sendResponse({
                        isShortenerPage,
                        isKnownShortener,
                        isSecurityPage,
                        countdownDetected,
                        destinationUrl,
                        hostname: window.location.hostname,
                        scanCount
                    });
                }, 1000);
                return true;

            case 'ACTIVATE_DRM_BYPASS':
                // User clicked the Screen Share Mode button in popup
                console.log('[KillURL] DRM bypass activation requested from popup');
                try {
                    window.dispatchEvent(new CustomEvent('killurl-force-drm-bypass'));
                } catch (e) { /* ignore */ }
                sendResponse({ success: true, needsReload: true });
                break;
        }
    });

    // Initialize
    init();
})();
